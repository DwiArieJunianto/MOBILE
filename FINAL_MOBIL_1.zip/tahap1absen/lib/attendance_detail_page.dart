import 'package:flutter/material.dart';

class AttendanceDetailPage extends StatefulWidget {
  final int meetingIndex;
  final Map<int, String> initialData;

  const AttendanceDetailPage({
    super.key,
    required this.meetingIndex,
    required this.initialData,
  });

  @override
  State<AttendanceDetailPage> createState() => _AttendanceDetailPageState();
}

class _AttendanceDetailPageState extends State<AttendanceDetailPage> {
  late Map<int, String> attendanceStatuses;
  final List<String> students = List.generate(30, (index) => 'Siswa ${index + 1}');

  @override
  void initState() {
    super.initState();
    attendanceStatuses = {...widget.initialData};
  }

  void _setAttendanceStatus(int index, String status) {
    setState(() {
      attendanceStatuses[index] = status;
    });
  }

  void _saveAttendance() {
    Navigator.pop(context, attendanceStatuses);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Kehadiran Pertemuan ${widget.meetingIndex}'),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          children: [
            // Header Tabel
            const Row(
              children: [
                Expanded(flex: 1, child: Text('No', style: TextStyle(fontWeight: FontWeight.bold))),
                Expanded(flex: 3, child: Text('Nama', style: TextStyle(fontWeight: FontWeight.bold))),
                Expanded(flex: 2, child: Text('Hadir', style: TextStyle(fontWeight: FontWeight.bold))),
                Expanded(flex: 2, child: Text('Izin', style: TextStyle(fontWeight: FontWeight.bold))),
                Expanded(flex: 2, child: Text('Alfa', style: TextStyle(fontWeight: FontWeight.bold))),
              ],
            ),
            const Divider(),

            // Data Kehadiran Siswa
            Expanded(
              child: ListView.builder(
                itemCount: students.length,
                itemBuilder: (context, index) {
                  return Row(
                    children: [
                      Expanded(flex: 1, child: Text('${index + 1}')), // No
                      Expanded(flex: 3, child: Text(students[index])), // Nama
                      
                      // Radio Buttons for Kehadiran Status
                      Expanded(
                        flex: 2,
                        child: Radio<String>(
                          value: 'Hadir',
                          groupValue: attendanceStatuses[index],
                          onChanged: (value) => _setAttendanceStatus(index, value!),
                        ),
                      ),
                      Expanded(
                        flex: 2,
                        child: Radio<String>(
                          value: 'Izin',
                          groupValue: attendanceStatuses[index],
                          onChanged: (value) => _setAttendanceStatus(index, value!),
                        ),
                      ),
                      Expanded(
                        flex: 2,
                        child: Radio<String>(
                          value: 'Alfa',
                          groupValue: attendanceStatuses[index],
                          onChanged: (value) => _setAttendanceStatus(index, value!),
                        ),
                      ),
                    ],
                  );
                },
              ),
            ),
          ],
        ),
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: _saveAttendance,
        child: const Icon(Icons.save),
      ),
    );
  }
}
