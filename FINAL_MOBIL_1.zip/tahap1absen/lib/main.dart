import 'package:flutter/material.dart';
import 'login_page.dart'; // Mengimpor halaman LoginPage
import 'teacher_dashboard.dart'; // Halaman Guru
// ignore: unused_import
import 'teacher_data.dart';
import 'student_dashboard.dart'; // Halaman Siswa
// ignore: unused_import
import 'student_data.dart';


void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Aplikasi Kehadiran',
      theme: ThemeData(primarySwatch: Colors.blue),
      initialRoute: '/',  // Mengarahkan ke halaman login
      routes: {
        '/': (context) => const LoginPage(role: ''),
        '/teacherDashboard': (context) => const TeacherDashboard(
          fullName: '', 
          gender: '', 
          nuptk: '', 
          phoneNumber: '', 
          subjects: [], userData: {}, nisn: '',
        ),
        '/studentDashboard': (context) => const StudentDashboard(
          fullName: '', 
          gender: '', 
          nisn: '', 
          phoneNumber: '', 
          studentClass: '', 
          subjects: [], userData: {},
        ),
      },
    );
  }
}
