// class_selection_page.dart
import 'package:flutter/material.dart';

class ClassSelectionPage extends StatelessWidget {
  final String role;
  final Map<String, dynamic> userData;

  const ClassSelectionPage({
    super.key,
    required this.role,
    required this.userData,
  });

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('$role - Pemilihan Kelas')),
      body: Center(
        child: Text('Selamat datang, ${userData['name']}'),
      ),
    );
  }
}
