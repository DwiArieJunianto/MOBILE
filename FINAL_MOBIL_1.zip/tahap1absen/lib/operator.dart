  import 'package:flutter/material.dart';

  class OperatorPage extends StatelessWidget {
    const OperatorPage({super.key});

    @override
    Widget build(BuildContext context) {
      return Scaffold(
        appBar: AppBar(
          title: const Text('Operator'),
          backgroundColor: Colors.blue,
        ),
        body: Center(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Image.asset(
                'assets/operator.png', // Gambar operator
                width: 400,
                height: 400,
              ),
              const SizedBox(height: 20),
              const Text(
                'Hubungi kami di WhatsApp:',
                style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
              ),
              const SizedBox(height: 10),
              const Text(
                '+62 853-7899-9873', // Nomor WhatsApp
                style: TextStyle(fontSize: 16, color: Colors.green),
              ),
            ],
          ),
        ),
      );
    }
  }
