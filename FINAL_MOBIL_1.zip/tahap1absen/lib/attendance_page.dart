import 'package:flutter/material.dart';
import 'attendance_detail_page.dart';

class AttendancePage extends StatefulWidget {
  final int classLevel;

  const AttendancePage({super.key, required this.classLevel});

  @override
  State<AttendancePage> createState() => _AttendancePageState();
}

class _AttendancePageState extends State<AttendancePage> {
  int _meetingCount = 3;

  // Menyimpan data kehadiran
  List<Map<int, String>> attendanceData = List.generate(3, (_) => {});

  void _addMeeting() {
    setState(() {
      _meetingCount++;
      attendanceData.add({});
    });
  }

  void _deleteMeeting(int index) {
    setState(() {
      if (_meetingCount > 0) {
        _meetingCount--;
        attendanceData.removeAt(index);
      }
    });
  }

  void _updateAttendance(int meetingIndex, Map<int, String> updatedData) {
    setState(() {
      attendanceData[meetingIndex] = updatedData;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Daftar Kehadiran Kelas ${widget.classLevel}'),
        actions: [
          IconButton(
            icon: const Icon(Icons.add),
            onPressed: _addMeeting,
          ),
        ],
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: ListView.builder(
          itemCount: _meetingCount,
          itemBuilder: (context, meetingIndex) {
            return Card(
              margin: const EdgeInsets.symmetric(vertical: 10),
              child: ListTile(
                title: Text('Pertemuan ${meetingIndex + 1}'),
                trailing: Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    IconButton(
                      icon: const Icon(Icons.edit),
                      onPressed: () async {
                        final updatedData = await Navigator.push<Map<int, String>>(
                          context,
                          MaterialPageRoute(
                            builder: (context) => AttendanceDetailPage(
                              meetingIndex: meetingIndex + 1,
                              initialData: attendanceData[meetingIndex],
                            ),
                          ),
                        );
                        if (updatedData != null) {
                          _updateAttendance(meetingIndex, updatedData);
                        }
                      },
                    ),
                    IconButton(
                      icon: const Icon(Icons.delete),
                      onPressed: () {
                        _deleteMeeting(meetingIndex);
                      },
                    ),
                  ],
                ),
              ),
            );
          },
        ),
      ),
    );
  }
}
