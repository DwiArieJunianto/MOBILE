import 'package:flutter/material.dart';
import 'package:tahap1absen/teacher_data.dart';

class TeacherDashboard extends StatelessWidget {
  final String fullName;
  final String gender;
  final String nuptk;
  final String phoneNumber;
  final List<Map<String, String>> subjects;

  const TeacherDashboard({
    super.key,
    required this.fullName,
    required this.gender,
    required this.nuptk,
    required this.phoneNumber,
    required this.subjects, required Map<String, dynamic> userData, required String nisn,
  });

  List<Map<String, String>> getSubjectsForClass(String className) {
    return subjects.where((subject) => subject['class'] == className).toList();
  }

Widget buildMyAccount() {
  return Card(
    elevation: 3,
    child: Padding(
      padding: const EdgeInsets.all(16.0),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            'My Account',
            style: TextStyle(
              fontSize: 18,
              fontWeight: FontWeight.bold,
              color: Colors.blue[800],
            ),
          ),
          const SizedBox(height: 10),
          Text('Nama: $fullName'),
          Text('Gender: $gender'),
          Text('NUPTK: $nuptk'),
          Text('Nomor HP: $phoneNumber'),
          // Full width SizedBox
          const SizedBox(
            width: double.infinity,
            child: SizedBox(height: 20), // This will span the entire width of the screen
          ),
          const SizedBox(height: 10),
          // Separate section for subjects
          Text(
            'Data Mata Pelajaran',
            style: TextStyle(
              fontSize: 18,
              fontWeight: FontWeight.bold,
              color: Colors.blue[800],
            ),
          ),
          const SizedBox(height: 10),
          // Display subjects here
          ...subjects.map((subject) {
            return Padding(
              padding: const EdgeInsets.only(bottom: 8.0),
              child: Text('Mata Pelajaran: ${subject['name']} (Kelas: ${subject['class']})'),
            );
          }),
        ],
      ),
    ),
  );
}


  Widget buildSubjects() {
    return ListView.builder(
      itemCount: subjects.length,
      itemBuilder: (context, index) {
        final subject = subjects[index];
        return Card(
          elevation: 2,
          child: ListTile(
            leading: const Icon(Icons.book, color: Colors.blue),
            title: Text(subject['name']!),
            subtitle: Text('Kelas: ${subject['class']}'),
            trailing: IconButton(
              icon: const Icon(Icons.visibility),
              onPressed: () {
                // Implement the action when the user wants to view the subject
                showDialog(
                  context: context,
                  builder: (context) => AlertDialog(
                    title: Text('Details for ${subject['name']}'),
                    content: const Text('More information about this subject.'),
                    actions: [
                      TextButton(
                        onPressed: () => Navigator.pop(context),
                        child: const Text('Close'),
                      ),
                    ],
                  ),
                );
              },
            ),
          ),
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Dashboard Guru'),
        actions: [
          IconButton(
            icon: const Icon(Icons.exit_to_app),
            onPressed: () {
              Navigator.pop(context); // Exit action
            },
          ),
        ],
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          children: [
            buildMyAccount(),
            const SizedBox(height: 20),
            Expanded(child: buildSubjects()),
          ],
        ),
      ),
    );
  }
}

void main() {
  final teacher = teacherData.firstWhere(
    (teacher) => teacher['nuptk'] == "",
    orElse: () => throw Exception("Data guru tidak ditemukan."),
  );

  runApp(MaterialApp(
    home: TeacherDashboard(
      fullName: teacher['fullName']!,
      gender: teacher['gender']!,
      nuptk: teacher['nuptk']!,
      phoneNumber: teacher['phoneNumber']!,
      subjects: List<Map<String, String>>.from(teacher['subjects']), userData: const {}, nisn: '',
    ),
  ));
}
