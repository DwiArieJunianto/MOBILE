package com.example.tahap1absen

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
